## Introduction

The original data is from [char-rnn-cn](https://github.com/leido/char-rnn-cn) and [char-rnn-tensorflow](https://github.com/sherjilozair/char-rnn-tensorflow).

