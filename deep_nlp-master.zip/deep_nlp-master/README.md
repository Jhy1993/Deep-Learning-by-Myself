# Deep NLP

## Introduction

The deep NLP application with TensorFlow to generate char-rnn text.

## Train

```
./generate_text.py
```

## Inference

```
./generate_text.py --mode inference --inference_start_word l
```
